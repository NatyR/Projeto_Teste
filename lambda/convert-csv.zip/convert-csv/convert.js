'use strict';
const csv = require('fast-csv');
const sanitizer = (str) => {
  //remove accents
  str = str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  //remove special characters
  str = str.replace(/[^a-zA-Z0-9\s]/g, '');
  //remove spaces
  //str = str.replace(/\s/g, '');
  //convert to upper case
  str = str.toUpperCase();
  return str;
};
const fillText = (str, length) => {
  //trim str
  str = str.trim();
  if (str.length > length) {
    return str.substring(0, length);
  }
  return str + ' '.repeat(length - str.length);
};
const fillNumber = (str, length) => {
  //trim str
  str = str.toString();
  str = str.trim();
  if (str.length > length) {
    return str.substring(0, length);
  }
  return '0'.repeat(length - str.length) + str;
};
const getPhone = (str, length = 9) => {
  //split by ')' and space
  var arr = str.split(') ');
  if (arr.length > 1) {
    str = arr[1];
  } else {
    str = arr[0];
  }
  str = str.replace(/[^0-9]/g, '');
  if (str.length > length) {
    return str.substring(-length);
  }
  return fillText(str, length);
};
const getFullPhone = (str, length = 15) => {
  //split by ')' and space
  str = str.replace(/[^0-9]/g, '');
  if (str.length > length) {
    return str.substring(-length);
  }
  return fillText(str, length);
};
const getDate = (str, def = '') => {
  str = str.toString();
  str = str.trim();
  if (def.length > 0 && str.length == 0) {
    str = def;
  }
  var arr = str.split('/');
  if (arr.length > 1) {
    str = arr.join('');
  }
  return fillNumber(str, 8);
};
const getDecimal = (str, integer = 8, decimals = 2) => {
  str = str.toString();
  str = str.trim();
  //if contains '.' and ',' remove '.' and replace ',' by '.'
  if (str.indexOf('.') > -1 && str.indexOf(',') > -1) {
    str = str.replace('.', '');
    str = str.replace(',', '.');
  }
  if (str.indexOf(',') > -1) {
    str = str.replace(',', '.');
  }
  arr = str.split('.');
  dec = arr[1] || '0';
  dec = dec + '0'.repeat(decimals - dec.length);
  return fillText(arr[0] + '.' + dec, integer + decimals);
};
const currentDate = () => {
  var today = new Date();
  var dd = today.getDate();
  var mm = today.getMonth() + 1; //January is 0!
  var yyyy = today.getFullYear();
  if (dd < 10) {
    dd = '0' + dd;
  }
  if (mm < 10) {
    mm = '0' + mm;
  }
  return dd + '/' + mm + '/' + yyyy;
};

module.exports = function convert(inFile, outFile, convenio) {
  return new Promise((resolve, reject) => {
    const stream = fs.createReadStream(inFile);
    const rows = [];
    csv
      .parseStream(stream, { headers: true, delimiter: ';', trim: true })
      .on('data', (data) => rows.push(data))
      .on('end', () => {
        console.log(rows);
        var output = fs.createWriteStream(outFile);
        output.once('open', function (fd) {
          rows.forEach(function (row) {
            var line = '';
            line += fillText('1', 8);
            line += fillText(sanitizer(row.Nome || ''), 65);
            line += fillText(sanitizer(row.Endereco || ''), 30);
            line += fillText(sanitizer(row.Numero || ''), 16);
            line += fillText(sanitizer(row.Bairro || ''), 20);
            line += fillText(sanitizer(row.Cidade || ''), 20);
            line += fillText(sanitizer(row.UF || ''), 2);
            row.Celular = '(11) 99970-0131';
            line += getFullPhone(row.Celular || '', 19);
            line += getDate(row['Data Nascimento'] || '');
            line += getDecimal(row.Limite || '0', 8, 2);
            line += getDate(row['Data Admissao'] || '', currentDate());
            line += fillText(row['Matricula'] || '', 10);
            line += fillText('', 6);
            line += fillText('', 4);
            line += fillNumber(convenio, 5) + '000';
            line += fillNumber('4', 2);
            line += fillNumber('0', 8); //Data demissão
            line += fillNumber(convenio, 5) + '000';
            line += fillNumber(row.CPF || '', 11);
            line += fillNumber(0, 2); //motivo segunda via
            line += fillNumber(0, 2); //motivo terceira via
            line += fillNumber(0, 2); //codigo de grupo de limite
            line += fillNumber(0, 16); //numero do cartao
            line += fillText(row.Email || '', 50); //email
            line += fillNumber(row.CNPJ || '', 14); // CNPJ
            line += fillText(row['Codigo Filial'] || '', 16); // Código da Filial
            line += fillText(row['Nome Filial'] || '', 64); // Nome da Filial
            line += fillText(row['Codigo Centro de Custo'] || '', 16); // Código do Centro de Custo
            line += fillText(row['Nome Centro de Custo'] || '', 40); // Centro de Custo
            line += fillText(row.Complemento || '', 24); // Complemento
            line += fillNumber(row.CEP || '', 8); // CEP
            line += fillNumber(row['Unidade Entrega'] || '0', 10); // Unidade de entrega
            line += fillText(row['Entrega Colaborador'] || 'N', 1); // Entrega no endereco do colaborador
            line += fillText(row['Sexo'] || '', 1); // Sexo
            line += fillText(row['Nacionalidade'] || '', 50); // Nacionalidade
            line += fillText(row['Cargo'] || '', 100); // Cargo
            line += fillText(row['Nome Mae'] || '', 50); // Nome da Mãe
            line += fillText(row['Nome Pai'] || '', 40); // Nome do Pai
            line += getFullPhone(row.Celular || '', 15);
            line += fillNumber(row.RG || '', 15); // RG
            line += fillText(row.Orgao || '', 10); // Orgao Emissor
            line += fillNumber('0', 8); // Data Retorno

            output.write(line + '\n');
          });
          output.end();
          resolve();
        });
      });
  });
};
